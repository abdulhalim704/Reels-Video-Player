package com.example.markup_map

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
